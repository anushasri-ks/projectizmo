package com.izmo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.entity.Movie;
import com.izmo.service.AdminService;
import com.izmo.service.CustomerService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	@RequestMapping(value = "/addMovie", method = RequestMethod.GET)
	public String addMovie()
	{
		return "addmovie";
	}
	
	@RequestMapping(value = "/addMovie1", method = RequestMethod.POST)
	public String addMovie1(@RequestParam("m_name") String m_name,
			@RequestParam("m_desc") String m_desc,
			@RequestParam("m_rdate") String m_rdate,
			@RequestParam("m_duration") String m_duration,
			@RequestParam("m_image") String m_image,
			@RequestParam("m_trailer") String m_trailer,Model model) 
	{
		Movie movie = new Movie();
 
		movie.setMovieName(m_name);
		movie.setMovieDescription(m_desc);
		movie.setReleaseDate(m_rdate);
		movie.setDuration(m_duration);
		movie.setCoverPhotoUrl(m_image);
		movie.setTrailerUrl(m_trailer);
		
		adminService.addMovies(movie);
//		List<Movie> movies=new ArrayList<Movie>();
//		movies=adminService.getMovies();
		model.addAttribute("msg", "One Movie Data added Successfully");
		return "addmovie";
		
	}
	
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public String viewMovie(Model model) {
		List<Movie> movies=new ArrayList<Movie>();
		movies=adminService.getMovies();
		model.addAttribute("movies", movies);
		return "adminviewmovies";
		
	}
	
	@RequestMapping(value = "/updatemovie", method = RequestMethod.GET)
	public String updatemovie(Model model)
	{ 
			List<Movie> movies=new ArrayList<Movie>();
			movies=adminService.getMovies();
			model.addAttribute("movies", movies);
			 
		return "adminupdatemovie";
	}
	@RequestMapping(value = "/updatemovieform", method = RequestMethod.GET)
	public String updateMovieForm(@RequestParam("id")String id, Model model)
	{ 
	
		Movie movie1=adminService.updateMovie(Integer.parseInt(id));
		model.addAttribute("movie", movie1);
				
		return "movieupdateform";
	}
	@RequestMapping(value = "/updatemovie1", method = RequestMethod.POST)
	public String updatemovie1(@RequestParam("m_id") String id,
			@RequestParam("m_name") String m_name,
			@RequestParam("m_desc") String m_desc,
			@RequestParam("m_rdate") String m_rdate,
			@RequestParam("m_duration") String m_duration,
			@RequestParam("m_image") String m_image,
			@RequestParam("m_trailer") String m_trailer,Model model) 
	{
		Movie movie = new Movie();
		movie.setMovieId(Integer.parseInt(id));
		movie.setMovieName(m_name);
		movie.setMovieDescription(m_desc);
		movie.setReleaseDate(m_rdate);
		movie.setDuration(m_duration);
		movie.setCoverPhotoUrl(m_image);
		movie.setTrailerUrl(m_trailer);
		
		adminService.updateMovies(movie);
//		List<Movie> movies=new ArrayList<Movie>();
//		movies=adminService.getMovies();
		model.addAttribute("msg", "One Movie Data Updated Successfully");
		return "movieupdateform";
		
	}
	@RequestMapping(value = "/deletemovie", method = RequestMethod.GET)
	public String deletemovie(Model model)
	{ 
			List<Movie> movies=new ArrayList<Movie>();
			movies=adminService.getMovies();
			model.addAttribute("movies", movies);
			 
		return "admindeletemovie";
	}
	
	@RequestMapping(value = "/deletemovieform", method = RequestMethod.GET)
	public String deleteMovieForm(@RequestParam("id")String id,Model model)
	{ 
		adminService.deleteMovie(Integer.parseInt(id));
			List<Movie> movies=new ArrayList<Movie>();
			movies=adminService.getMovies();
			model.addAttribute("movies", movies);
			 
		return "admindeletemovie";
	}

}
