package com.izmo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.service.CustomerService;
import com.izmo.service.LoginService;

import net.bytebuddy.asm.Advice.Return;

@Controller
@RequestMapping("/login")
public class LoginController {

	@Autowired
	LoginService loginService;

	static String loginid = null;
	static String password = null;

	@RequestMapping("/")
	public String getMessage() {
		return "index";
	}

	@RequestMapping("/login")
	public String getResult(@RequestParam("user") String name, @RequestParam("pwd") String pswd, Model model) {

		loginid = name;
		password = pswd;
		System.out.println("loginid "+loginid+" password "+password);
		String type = loginService.getType(name, pswd);
		if (type != null) {
			System.out.println("This is type  " + type);
			if (type.equals("admin")) {
				return "adminhomepage";
			} else if (type.equals("customer")) {
				return "customerhome";
			}
			return "customerhome";
		} else {
			model.addAttribute("msg", "Invalid Credentials!!!");
			return "index";
		}
	}

}
