package com.izmo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.izmo.entity.Customer;
@Repository
public interface CustomerRepo extends JpaRepository<Customer, Integer> {

	@Query("select c from Customer c where c.login.loginid=:id")
	public Customer getCustomerByLoginId(@Param("id")String id);


 
//	@Query("update customer c set c.fname = ?1,c.lname = ?2,c.email = ?3,c.mobileNo = ?4,c.dob = ?5 where c.customerId = ?6")
//			 
//	public void updateById(String getfName, String getlName, String email, String mobileNo, String dob, int id);

}
