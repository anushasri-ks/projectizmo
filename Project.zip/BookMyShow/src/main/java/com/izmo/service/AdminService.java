package com.izmo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.entity.Movie;
import com.izmo.repo.CustomerRepo;
import com.izmo.repo.LoginRepo;
import com.izmo.repo.MovieRepo;

@Service
public class AdminService {
	
	@Autowired
	CustomerRepo customerRepo;
	
	@Autowired
	MovieRepo movieRepo;
	
	@Autowired
	LoginRepo loginRepo;
	
	public void addMovies(Movie movie) {
		movieRepo.save(movie);
		
	}

	public List<Movie> getMovies() {
		return movieRepo.findAll();
		
	}

	public Movie updateMovie(int id) {
		List<Movie> lm=movieRepo.findAll();
		Movie movie=new Movie();
		for(Movie m:lm)
		{
			if(m.getMovieId()==id)
			{
				movie.setMovieId(id);
				movie.setMovieName(m.getMovieName());
				movie.setMovieDescription(m.getMovieDescription());
				movie.setReleaseDate(m.getReleaseDate());
				movie.setDuration(m.getDuration());
				movie.setCoverPhotoUrl(m.getCoverPhotoUrl());
				movie.setTrailerUrl(m.getTrailerUrl());
			}
		}
		return movie;
	}

	public void updateMovies(Movie movie) {
		//movieRepo.deleteById(movie.getMovieId());
		movieRepo.save(movie);
	 
		
	}

	public void deleteMovie(int id) {
		movieRepo.deleteById(id);
		
	}


}
