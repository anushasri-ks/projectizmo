package com.izmo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.repo.CustomerRepo;
import com.izmo.repo.LoginRepo;
import com.izmo.repo.MovieRepo;

@Service
public class LoginService {
	@Autowired
	CustomerRepo customerRepo;
	
	@Autowired
	MovieRepo movieRepo;
	
	@Autowired
	LoginRepo loginRepo;
	
	public String getType(String name, String pswd) {
		 
		String type=loginRepo.getByIdAndPassword(name,pswd);
		System.out.println(type);
		return  type;
	}

}
