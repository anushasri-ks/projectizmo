package com.izmo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.entity.Customer;
import com.izmo.entity.Movie;
import com.izmo.repo.CustomerRepo;
import com.izmo.repo.LoginRepo;
import com.izmo.repo.MovieRepo;

@Service
public class CustomerService {

	@Autowired
	CustomerRepo customerRepo;
	
	@Autowired
	MovieRepo movieRepo;
	
	@Autowired
	LoginRepo loginRepo;
	

	
	public void register(Customer customer) {
		customerRepo.save(customer);
	}


	public List<Customer> getAll() {
		 List<Customer> list=customerRepo.findAll();
		return list;
	}

	public Customer updateCustomer(int id) {
		List<Customer> list=customerRepo.findAll();
		Customer c1=new Customer();
		for(Customer c:list)
		{
			if(c.getCustomerId()==id)
			{
				c1.setCustomerId(id);
				c1.setfName(c.getfName());
				c1.setlName(c.getlName());
				c1.setEmail(c.getEmail());
				c1.setMobileNo(c.getMobileNo());
				c1.setDob(c.getDob());
			}
		}
		return c1;
	}

	public Customer getCustomer(String loginid) {
		Customer customer=customerRepo.getCustomerByLoginId(loginid);	
			return customer;
		
	}

	public void updateCust(Customer customer) {
//		 customerRepo.deleteById(Integer.parseInt(id));
		customerRepo.save(customer);
 
			//customerRepo.updateById(customer.getfName(),customer.getlName(),customer.getEmail(),customer.getMobileNo(),customer.getDob(),customer.getCustomerId());
		 
	}

	public void deleteCustomer(int id) {
		customerRepo.deleteById(id);

	}


	public void chaangePass(String npass, String loginid) {
		loginRepo.changePassword(npass,loginid);
	}


}
