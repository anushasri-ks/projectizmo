package com.util;
import java.sql.*;
	public class Myconn {

		public static Connection getCon()
		{
			
			String driver="com.mysql.cj.jdbc.Driver";
			String url="jdbc:mysql://10.125.2.15:3306/anushasri";
			String uid="anushasri";
			String pswd="anu435";
			
			try{
				Class.forName(driver);//1
				Connection con=DriverManager.getConnection(url, uid, pswd);//2
	          System.out.println("Connection established");
			  return con;
			
			}catch(Exception e){e.printStackTrace();}
			return null;
			
		}
	}


