package com.dao;


import java.sql.SQLException;
import java.util.List;

import com.model.Student;

public interface StudentDao {

	int add(Student s) throws SQLException;
	void update(Student s) throws SQLException;
	int delete(int id) throws SQLException;
	Student findById(int a)throws SQLException;
	List<Student> read() throws SQLException;
	
	
}
