package com.Izmo.sachin;

import java.sql.*;
public class Mycon {

	public static void getCon()
	{	
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://10.125.2.15:3306/anushasri";
		String uid="anushasri";
		String pswd="anu435";
		
		try{
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url, uid, pswd);
			Statement st=con.createStatement();
			System.out.println("Connection established");
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("select * from employees");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
			con.close();  
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}