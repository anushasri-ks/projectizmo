package com.sac;
import java.util.*;

public class Sachi {
int id; 
String name;
String address;
String mot;
private String subjects[];
private static int rand()
{
	return (int)(Math.random()*100+1);	
}
public void setId()
{
this.id=Sachi.rand();	
}
public int getId() {
	return id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getMot() {
	return mot;
}
public void setMot(String mot) {
	this.mot = mot;
}
public Sachi(int id, String name, String address, String mot) {
	super();
	this.id = id;
	this.name = name;
	this.address = address;
	this.mot = mot;
}
public Sachi() {
	super();
	// TODO Auto-generated constructor stub
}
public String getSubjects() {
	String s="";
	for(String x:subjects)
		s+=x+" ";
	return s;
}
public void setSubjects(String[] subjects) {
	this.subjects = subjects;
}

}
