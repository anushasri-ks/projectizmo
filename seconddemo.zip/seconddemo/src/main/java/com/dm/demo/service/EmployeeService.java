package com.dm.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dm.demo.model.Employee;
import com.dm.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository repository;
	
	public void deleteEmployee(int id)
	{
		repository.deleteById(id);
	}
	
	public void addEmployee(Employee e)
	{
				
				repository.save(e);
		
	}
	
	public void updateEmployee(Employee e)
	{
		repository.save(e);
	}			
		
	public List<Employee> getAllEmployees()
		{
			return repository.findAll();
		}

	public boolean update(Employee emp) {
		boolean b=false;
 List<Employee> emp1=repository.findAll();
 for(Employee e:emp1)
 {
	 if(e.getId()==emp.getId())
	 {
		 repository.save(emp);
		 b=true;
	 }
 }
	 
		return b;
		 		
	}

	public void deleteById(int id) {
		repository.deleteById(id);
		
	}
	}

